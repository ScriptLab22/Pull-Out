Ein einfaches Pull Out Script für FiveM ESX Legacy

Es ermöglicht für alle Spieler Bewusstlose Personen aus dem Auto zu ziehen.

Da es vorerst eine Notlösung ist muss die ID mit angegeben werden.

Ich werde dieses Script weiter entwickeln so das man keine ID mehr angeben muss.

zurzeit ist der befehl /pullout [ID]

Entwickelt von Script Lab

Discord: https://discord.gg/Te2B9AW86R